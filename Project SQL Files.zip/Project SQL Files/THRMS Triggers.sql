-- ALL THE STORED PROCEDURES USED IN THE THRMS SEMESTER PROJECT

delimiter //
create trigger insert_train
after insert on train
for each row 
begin
insert into backlog(entry_time, description, currentUser)
values(NOW(), concat("Inserted new train with ID ", new.train_id, " into Train table"), user());
end //

create trigger update_train
after update on train
for each row 
begin
insert into backlog(entry_time, description, currentUser)
values(NOW(), concat("Updated train with ID ", new.train_id, " in Train table"), user());
end //

create trigger insert_station
after insert on station
for each row 
begin
insert into backlog(entry_time, description, currentUser)
values(NOW(), concat("Inserted new station with ID ", new.station_id, " into Station table"), user());
end //

create trigger update_station
after update on station
for each row 
begin
insert into backlog(entry_time, description, currentUser)
values(NOW(), concat("Updated station with ID ", new.station_id, " in Station table"), user());
end //

create trigger insert_journey
after insert on journey
for each row 
begin
insert into backlog(entry_time, description, currentUser)
values(NOW(), concat("Inserted new journey with ID ", new.journey_id, " into Journey table"), user());
end //

create trigger update_journey
after update on journey
for each row 
begin
insert into backlog(entry_time, description, currentUser)
values(NOW(), concat("Updated journey with ID ", new.journey_id, " in Journey table"), user());
end //

create trigger update_rates
after update on rates
for each row 
begin
insert into backlog(entry_time, description, currentUser)
values(NOW(), concat("Updated rate with ID ", new.id, " in Rates table"), user());
end //

delimiter ;