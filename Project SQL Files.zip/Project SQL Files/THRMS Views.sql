-- ALL THE VIEWS USED IN THE THRMS SEMESTER PROJECT

-- creating a view that gives complete information regarding a customer 
-- after combining their information from person and customer tables
CREATE VIEW railway2_view_customer_info 
AS (SELECT * FROM person NATURAL JOIN customer);

-- creating a view that gives complete information regarding a adminticket 
-- after combining their information from person and admin tables
CREATE VIEW railway2_view_admin_info
AS (SELECT * FROM person NATURAL JOIN admin);

-- creating a view that gives information regarding the booked tickets of a customer
CREATE VIEW railway2_view_myjourneys_info
AS (SELECT customer_id, passenger_id, journey_id, name, departure_date, arrival_date, departure_time, arrival_time, class, cargo, seat, payment_completed
FROM journey NATURAL JOIN passenger_payment NATURAL JOIN ticket NATURAL JOIN train);
 
