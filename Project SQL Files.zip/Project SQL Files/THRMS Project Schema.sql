-- CRREATING A DATABASE FOR THE THRMS SEMESTER PROJECT

create database railway2;
use railway2;

-- ADMIN, CUSTOMER, ENGINEER ARE ALL PERSON : GNERALIZARTION

-- CREATING PERSON TABLE
CREATE TABLE railway2.person(
  cnic char(14) NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NULL DEFAULT NULL,
  mobile_number VARCHAR(12) NOT NULL,
  PRIMARY KEY (cnic),
  UNIQUE(mobile_number));
  
  -- CREATE ADMIN TABLE
CREATE TABLE `railway2`.`admin` (
  cnic CHAR(13) NOT NULL,
  special_number CHAR(10) NOT NULL,
  salary FLOAT NOT NULL,
  designation VARCHAR(30) default NULL,
  PRIMARY KEY (cnic),
  UNIQUE (special_number),
  CONSTRAINT `fk_cnic_in_admin` FOREIGN KEY (cnic) REFERENCES railway2.person(cnic)
  on delete cascade 
  on update cascade);
  
  -- CREATING CUSTOMER TABLE
CREATE TABLE `railway2`.`customer`(
`cnic` char(13) NOT NULL,
`password` VARCHAR(45) NOT NULL,
`date_of_birth` DATE NOT NULL,
`gender` CHAR(1) NOT NULL,
`nearest_station` VARCHAR(45) NOT NULL,
PRIMARY KEY (`cnic`),
CONSTRAINT `fk_cnic_in_customer` FOREIGN KEY (`cnic`) REFERENCES `railway2`.`person` (`cnic`)
	ON DELETE CASCADE
	ON UPDATE CASCADE,
CONSTRAINT `check_gender` check(gender in ("F", "M", "O")),
CONSTRAINT `check_date_of_birth` check(date_of_birth<concat(year(sysdate()) - 18, "-01-01")));

-- CREATING ENGINEER TABLE
CREATE TABLE `railway2`.`engineer`(
`cnic` char(13) NOT NULL,
`salary` FLOAT NOT NULL,
`experience` INT DEFAULT 0,
PRIMARY KEY (`cnic`),
CONSTRAINT `fk_cnic_in_engineer` FOREIGN KEY (`cnic`) REFERENCES `railway2`.`person` (`cnic`)
	ON DELETE CASCADE
	ON UPDATE CASCADE);
    
    -- CREATE STATION REALTION
CREATE TABLE `railway2`.`station`(
  `station_id` INT NOT NULL,
  `city` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`station_id`),
  UNIQUE (`city`));
  
  -- CREATE TRAIN RELATION
CREATE TABLE `railway2`.`train`(
  `train_id` INT NOT NULL,
  `name` VARCHAR(45) NOT NULL,
  `engineer_id` char(13) NOT NULL,
  PRIMARY KEY (`train_id`),
  CONSTRAINT `fk_engineer_id_in_train`
    FOREIGN KEY (`engineer_id`)
    REFERENCES `railway2`.`engineer` (`cnic`)
    ON DELETE NO ACTION
    ON UPDATE CASCADE);
    
    -- CREATE ROUTE REALTION
CREATE TABLE `railway2`.`route` (
  `route_id` INT NOT NULL,
  `departure_station_id` INT NOT NULL,
  `arrival_station_id` INT NOT NULL,
  `distance` FLOAT NOT NULL,
  PRIMARY KEY (`route_id`),
  CONSTRAINT `fk_arrival_station_id_in_route`
    FOREIGN KEY (`departure_station_id`) REFERENCES `railway2`.`station` (`station_id`)
    ON DELETE NO ACTION
    ON UPDATE CASCADE,
  CONSTRAINT `fk_dept_station_id_in_route`
    FOREIGN KEY (`arrival_station_id`) REFERENCES `railway2`.`station` (`station_id`)
    ON DELETE NO ACTION
    ON UPDATE CASCADE);
    
    -- CREATE JOUNEY RELATION
CREATE TABLE `railway2`.`journey`(
  `journey_id` INT NOT NULL,
  `train_id` INT NOT NULL,
  `route_id` INT NOT NULL,
  `departure_date` DATE NOT NULL,
  `arrival_date` DATE NOT NULL,
  `departure_time` TIME NOT NULL,
  `arrival_time` TIME NOT NULL,
  PRIMARY KEY (`journey_id`),
  CONSTRAINT `fk_train_id_in_journey` FOREIGN KEY (`train_id`) REFERENCES `railway2`.`train` (`train_id`)
    ON DELETE NO ACTION
    ON UPDATE CASCADE,
  CONSTRAINT `fk_route_id_in_journey` FOREIGN KEY (`route_id`) REFERENCES `railway2`.`route` (`route_id`)
    ON DELETE NO ACTION
    ON UPDATE CASCADE);
    
    # PAYMENT_METHOD TABLE
CREATE TABLE `railway2`.`payment_method`(
  `method_id` INT NOT NULL,
  `name` CHAR(13) NOT NULL,
  primary key(method_id));
  
  # PASSENGER_PAYMENT TABLE
# 1 CUSTOMER CAN BECOME PASSENEGER FOR FOR MANY JOUNEYS
CREATE TABLE `railway2`.`passenger_payment` (
  `passenger_id` INT NOT NULL AUTO_INCREMENT,
  `customer_id` CHAR(13) NOT NULL,
  `journey_id` INT NOT NULL,
  `due_amount` FLOAT NOT NULL,
  `paid_amount` FLOAT DEFAULT 0 NOT NULL,
  `issue_date` DATE NOT NULL,
  `payment_date` DATE DEFAULT NULL,
  `due_date` date default NULL,
  `payment_method` int DEFAULT NULL,
  PRIMARY KEY (`passenger_id`),
  UNIQUE(`customer_id`, `journey_id`), 
  # all pairs of customer_id and journey_id are unique, 
  # if a customer buys multiple tickets for their family(example 4 members), they will be entered into the table once once with the total payemnt amount they need to pay
  # however the ticket table will have all the 4 seats reserved under one passenger_id
  CONSTRAINT `check_paid_amount_in_passenger` check(`paid_amount` in (0, due_amount)),
  CONSTRAINT `check_payment_date_in_passenger` check(`payment_date` between `issue_date` and `due_date`),
  CONSTRAINT `fk_customer_id_in_passenger_payment` FOREIGN KEY (`customer_id`) references `customer`(`cnic`)
    ON DELETE CASCADE # PASSENGER WILL BE DELETED ONCE THE CUSTOMER IS DELETED
    ON UPDATE CASCADE, # PASSENGER WILL BE UPDATED ONCE THE CUSTOMER IS UPDATED
  CONSTRAINT `fk_journey_id_in_passenger_payment` FOREIGN KEY (`journey_id`) references `journey`(`journey_id`)
    ON DELETE CASCADE # PASSENGER'S JOUNEY WILL BE DELETED ONCE THE JOURNEY IS DELETED
    ON UPDATE NO ACTION, # PASSENGER'S JOUNEY WILL BE DELETED ONCE THE JOURNEY IS DELETED
  CONSTRAINT `fk_payment_method_in_passenger_payment` FOREIGN KEY (`payment_method`) references `payment_method`(`method_id`)
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
    );
    
    # TICKET TABLE
CREATE TABLE `railway2`.`ticket` (
  `passenger_id` INT NOT NULL,
  `class` CHAR(1) NOT NULL,
  `cargo` CHAR(1) NOT NULL,
  `seat` INT NOT NULL,
  `payment_completed` INT DEFAULT 0,
  PRIMARY KEY(passenger_id, class, cargo, seat),
  UNIQUE(passenger_id, class, cargo, seat),
  CONSTRAINT `check_payment_completed` check(payment_completed in (0, 1)),
  CONSTRAINT `fk_passenger_id_in_ticket` FOREIGN KEY (`passenger_id`) references `passenger_payment`(`passenger_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE);
    
    # RATES TABLE
    CREATE TABLE `railway2`.`rates` (
  `id` INT NOT NULL,
  `name` VARCHAR(45) NOT NULL,
  `value` FLOAT NOT NULL,
  `last_admin` varchar(50) NOT NULL Default "2990357144098",
  PRIMARY KEY (`id`),
  UNIQUE(`name`),
  CONSTRAINT `admin_in_rates` foreign key (`last_admin`) references admin(`cnic`));
  
  # GENERAL SEATING TABLE
  CREATE TABLE `railway2`.`general_seating` (
  `id` INT NOT NULL,
  `class` CHAR(1) NOT NULL,
  `cargo` CHAR(1) NOT NULL,
  `seat` INT NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE (class, cargo, seat),
  CONSTRAINT `check_class` check(class in ("B", "E")),
  CONSTRAINT `check_cargo` check(cargo in ("A","B", "C", "D","E")),
  CONSTRAINT `check_seat` check(seat between 1 and 130) );
  
-- BACKLOG TABLE
create table backlog(
id int not null auto_increment,
entry_time varchar(50) not null,
description varchar (50) not null,
currentUser varchar(50) not null,
primary key(id)
);