-- ALL THE STORED PROCEDURES USED IN THE THRMS SEMESTER PROJECT

-- PROCEDURE: available_seats_journey_cargo
-- INPUT: journey_id and cargo number
-- OUPUT: returns the records of all the available seats
DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `available_seats_journey_cargo`(j int, c char(1))
BEGIN
	select * from general_seating where (class, cargo, seat) not in 
	(select class, cargo, seat from passenger_payment pp natural join ticket t where journey_id = j) and cargo=c;
END$$
DELIMITER ;

-- PROCEUDRE: get_due_date_for_payment
-- INPUT: journey_id
-- OUPUT: returns the due dates for the journeys that are at least 2 days before the current date
DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_due_date_for_payment`(j int)
BEGIN
	select DATE_SUB(departure_date, INTERVAL 2 DAY) from journey where journey_id = j;
END$$
DELIMITER ;

-- PROCEUDRE: get_journeys_from_cities
-- INPUT: two cities present in the station table
-- OUPUT: returns all the incomplete journeys between the two cities
DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_journeys_from_cities`(c1 varchar(50), c2 varchar(50))
BEGIN
select j.journey_id, t.name, j.route_id, 
departure_date, arrival_date, departure_time, arrival_time, distance 
from route r natural join journey j natural join train t where j.route_id = 
	(select route_id from 
		(select route_id, departure_station_id, city as departure_city
		from station s join route r 
		on s.station_id = r.departure_station_id 
		where city = c1) t1 
		natural join
		(select route_id, arrival_station_id, city as arrival_city
		from station s join route r 
		on s.station_id = r.arrival_station_id 
		where city=c2) t2)
and departure_date>date_add(curdate(), INTERVAL 3 DAY);
END$$
DELIMITER ;


-- PROCEUDRE: my_journeys
-- INPUT: cnic of the customer currently logged in
-- OUPUT: returns all the journeys of the customer has booked that are incomplete
DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `my_journeys`(CNIC char(14))
BEGIN
SELECT customer_id, passenger_id, journey_id, name, arrival_station, departure_station, departure_date, arrival_date, departure_time, arrival_time, class, cargo, seat
FROM journey 
NATURAL JOIN passenger_payment 
NATURAL JOIN ticket 
NATURAL JOIN train 
NATURAL JOIN route 
NATURAL JOIN 
	(SELECT *
	FROM (SELECT route_id, s.city AS departure_station
	FROM route r JOIN station s WHERE r.departure_station_id = s.station_id) AS T1
	NATURAL JOIN
	(SELECT route_id, s.city AS arrival_station
	FROM route r JOIN station s WHERE r.arrival_station_id = s.station_id) AS T2) AS fromto
WHERE customer_id = CNIC AND ADDTIME(CONVERT(DATE(departure_date), DATETIME), TIME(departure_time)) > NOW();
END$$
DELIMITER ;