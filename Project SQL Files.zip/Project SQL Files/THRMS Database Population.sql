-- THIS FILE CONTAINS ALL THE VALUES INSERTED INTO THE DATABASE

-- INSERTING VALUES IN  PERSON TABLE (25 records -> 15 cust, 3 admin, 7 engineers) 
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('6511585293123', 'Mohammad ', 'Basheer', '03153095949');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('4973493225135', 'Mohhamad', 'Faheem', '03080923159');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('2990357144098', 'Syed', 'Amir', '03182254888');

INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('8438223769986', 'Ayesha', 'Khan', '03050610478');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('6605690768708', 'Mohammad Ali', default, '03409227533');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('2918677851617', 'Ayesha', 'Khan', '03050610488');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('8599945574538', 'Ayesha', 'Omar', '03449064297');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('6080119405728', 'Sana', 'Amir', '03758720847');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('8855614578685', 'Hamza', 'Amir', '03004032836');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('2366045628729', 'Farha', 'Younus', '03272722386');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('2317418187872', 'Aneeque', 'Ahmed', '03054489055');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `mobile_number`) VALUES ('8538627985282', 'Manzoor Ahmed Khan', '03355225435');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('4638806264292', 'Farhan', 'Naime', '03125820884');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('4638806796232', 'Saleha', 'Shariff', '03750996724');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('8648907319135', 'Haniah', 'Shanff', '03322452563');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('2141016577927', 'Abdullah', 'Naime', '03493640363');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('0470789309283', 'Abdullah', 'Khan', '03571652833');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `mobile_number`) VALUES ('5408737347182', 'Abdullah Miraaj', '03644932292');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('7231293246292', 'Osama', 'Faheem', '03017940952');

INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('8480161299282', 'Parwaez', 'Hussain', '03308384881');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('5893960636128', 'Zulfiqar', 'Imran', '03449468701');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('6168275750333', 'Arham', 'Rizwan', '03260552184');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('4215945444444', 'Talha', 'Aftab', '03416178905');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('4215945123253', 'Zubair', 'Chaudry', '03154099736');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('4215941209314', 'Qasim', 'Khan', '03216421630');
INSERT INTO `railway2`.`person` (`cnic`, `first_name`, `last_name`, `mobile_number`) VALUES ('9643043904755', 'Mohammad Sajjid Chaudry', default, '03235905957');

-- INSERT VALUES INTO ADMIN TABLE
INSERT INTO `railway2`.`admin` (`cnic`, `special_number`, `salary`, `designation`) VALUES ('6511585293123', '1234567890', '80000', 'admin1');
INSERT INTO `railway2`.`admin` (`cnic`, `special_number`, `salary`, `designation`) VALUES ('4973493225135', '1212121212', '100000', 'admin2');
INSERT INTO `railway2`.`admin` (`cnic`, `special_number`, `salary`) VALUES ('2990357144098', '0987654321', '90000');

-- INSERTING VALUES IN  CUSTOMER TABLE
INSERT INTO `railway2`.`customer` (`cnic`, `password`, `date_of_birth`, `gender`, `nearest_station`) VALUES ('8438223769986', 'Vbh52ITX63', '1968-04-05', 'F', 'Karachi');
INSERT INTO `railway2`.`customer` (`cnic`, `password`, `date_of_birth`, `gender`, `nearest_station`) VALUES ('6605690768708', '7VTzAVx*.ay', '1969-10-29', 'M', 'Karachi');
INSERT INTO `railway2`.`customer` (`cnic`, `password`, `date_of_birth`, `gender`, `nearest_station`) VALUES ('2918677851617', '5mEywcU5su', '1970-07-22', 'F', 'Karachi');
INSERT INTO `railway2`.`customer` (`cnic`, `password`, `date_of_birth`, `gender`, `nearest_station`) VALUES ('8599945574538', 'aQiJVrc9xM', '1973-07-27', 'F', 'Lahore');
INSERT INTO `railway2`.`customer` (`cnic`, `password`, `date_of_birth`, `gender`, `nearest_station`) VALUES ('6080119405728', '7EmOr6*.V7s', '1975-09-23', 'F', 'Lahore');
INSERT INTO `railway2`.`customer` (`cnic`, `password`, `date_of_birth`, `gender`, `nearest_station`) VALUES ('8855614578685', 'awl9ymVSU0', '1977-01-16', 'M', 'Lahore');
INSERT INTO `railway2`.`customer` (`cnic`, `password`, `date_of_birth`, `gender`, `nearest_station`) VALUES ('2366045628729', '1fon2MAWfh', '1978-01-28', 'F', 'Hyderabad');
INSERT INTO `railway2`.`customer` (`cnic`, `password`, `date_of_birth`, `gender`, `nearest_station`) VALUES ('2317418187872', 'NaFrtGsGmz', '1982-10-01', 'M', 'Sialkot');
INSERT INTO `railway2`.`customer` (`cnic`, `password`, `date_of_birth`, `gender`, `nearest_station`) VALUES ('8538627985282', 'BDgpqE1HDV', '1983-09-24', 'M', 'Islamabad');
INSERT INTO `railway2`.`customer` (`cnic`, `password`, `date_of_birth`, `gender`, `nearest_station`) VALUES ('4638806264292', 'YNQ45AuTHH', '1984-02-04', 'M', 'Multan');
INSERT INTO `railway2`.`customer` (`cnic`, `password`, `date_of_birth`, `gender`, `nearest_station`) VALUES ('4638806796232', 'X4JUH*.S*.Y2', '1986-09-17', 'F', 'Murree');
INSERT INTO `railway2`.`customer` (`cnic`, `password`, `date_of_birth`, `gender`, `nearest_station`) VALUES ('8648907319135', 'STQknu8IV2', '1987-11-29', 'F', 'Peshawar');
INSERT INTO `railway2`.`customer` (`cnic`, `password`, `date_of_birth`, `gender`, `nearest_station`) VALUES ('2141016577927', '8HzKaOX8wY', '1990-10-10', 'M', 'Quetta');
INSERT INTO `railway2`.`customer` (`cnic`, `password`, `date_of_birth`, `gender`, `nearest_station`) VALUES ('0470789309283', 'lVat*.24yLR', '1991-01-20', 'M', 'Abbottabad');
INSERT INTO `railway2`.`customer` (`cnic`, `password`, `date_of_birth`, `gender`, `nearest_station`) VALUES ('5408737347182', '9rDpT8qzYw', '1992-12-14', 'M', 'Attock');
INSERT INTO `railway2`.`customer` (`cnic`, `password`, `date_of_birth`, `gender`, `nearest_station`) VALUES ('7231293246292', '74WEhmSh6t', '1996-03-04', 'M', 'Lahore');

-- INSERTING VALUES IN ENGINEER TABLE
INSERT INTO `railway2`.`engineer` (`cnic`, `salary`, `experience`) VALUES ('8480161299282', '90000', '4');
INSERT INTO `railway2`.`engineer` (`cnic`, `salary`, `experience`) VALUES ('5893960636128', '98000', '7');
INSERT INTO `railway2`.`engineer` (`cnic`, `salary`, `experience`) VALUES ('6168275750333', '180000', '13');
INSERT INTO `railway2`.`engineer` (`cnic`, `salary`, `experience`) VALUES ('4215945444444', '200000', '16');
INSERT INTO `railway2`.`engineer` (`cnic`, `salary`, `experience`) VALUES ('4215945123253', '75000', '0');
INSERT INTO `railway2`.`engineer` (`cnic`, `salary`, `experience`) VALUES ('4215941209314', '75000', '0');
INSERT INTO `railway2`.`engineer` (`cnic`, `salary`, `experience`) VALUES ('9643043904755', '10500', '10');

-- INSERT VALUES INTO STATION RELATION
INSERT INTO `railway2`.`station` (`station_id`, `city`) VALUES ('1', 'Karachi');
INSERT INTO `railway2`.`station` (`station_id`, `city`) VALUES ('2', 'Hyderabad');
INSERT INTO `railway2`.`station` (`station_id`, `city`) VALUES ('3', 'Lahore');
INSERT INTO `railway2`.`station` (`station_id`, `city`) VALUES ('4', 'Sialkot');
INSERT INTO `railway2`.`station` (`station_id`, `city`) VALUES ('5', 'Attock');
INSERT INTO `railway2`.`station` (`station_id`, `city`) VALUES ('6', 'Multan');
INSERT INTO `railway2`.`station` (`station_id`, `city`) VALUES ('7', 'Abbottabad');
INSERT INTO `railway2`.`station` (`station_id`, `city`) VALUES ('8', 'Muree');
INSERT INTO `railway2`.`station` (`station_id`, `city`) VALUES ('9', 'Islamabad');
INSERT INTO `railway2`.`station` (`station_id`, `city`) VALUES ('10', 'Peshawar');
INSERT INTO `railway2`.`station` (`station_id`, `city`) VALUES ('11', 'Quetta');

# INSERT VALUES IN TRAIN RELATION
# PROGRAMMING ===== NUMBER OF TRAINS SHOULD ALWAYS BE LESS OR EQUAL TO THE NUMBER OF ENGINEERS BECAUSE AT A TIME AN ENGINEER CAN DRIVE ONLY ONE TRAIN
INSERT INTO `railway2`.`train` (`train_id`, `name`, `engineer_id`) VALUES ('1', 'Nawaz', '4215941209314');
INSERT INTO `railway2`.`train` (`train_id`, `name`, `engineer_id`) VALUES ('2', 'Tehzeeb', '4215945123253');
INSERT INTO `railway2`.`train` (`train_id`, `name`, `engineer_id`) VALUES ('3', 'Naya Raasta', '4215945444444');
INSERT INTO `railway2`.`train` (`train_id`, `name`, `engineer_id`) VALUES ('4', 'Jinnah Express', '5893960636128');
INSERT INTO `railway2`.`train` (`train_id`, `name`, `engineer_id`) VALUES ('5', 'Agha Rails', '6168275750333');
INSERT INTO `railway2`.`train` (`train_id`, `name`, `engineer_id`) VALUES ('6', 'Ghazni Rails', '8480161299282');


# INSERTING VALUES INTO ROUTE TABLE
INSERT INTO `railway2`.`route` (`route_id`, `departure_station_id`, `arrival_station_id`, `distance`) VALUES ('1', '1', '2', '143.74');
INSERT INTO `railway2`.`route` (`route_id`, `departure_station_id`, `arrival_station_id`, `distance`) VALUES ('2', '1', '3', '1225');
INSERT INTO `railway2`.`route` (`route_id`, `departure_station_id`, `arrival_station_id`, `distance`) VALUES ('3', '2', '1', '143.74');
INSERT INTO `railway2`.`route` (`route_id`, `departure_station_id`, `arrival_station_id`, `distance`) VALUES ('4', '2', '3', '150');
INSERT INTO `railway2`.`route` (`route_id`, `departure_station_id`, `arrival_station_id`, `distance`) VALUES ('5', '2', '11', '707');
INSERT INTO `railway2`.`route` (`route_id`, `departure_station_id`, `arrival_station_id`, `distance`) VALUES ('6', '3', '1', '1225');
INSERT INTO `railway2`.`route` (`route_id`, `departure_station_id`, `arrival_station_id`, `distance`) VALUES ('7', '3', '2', '150');
INSERT INTO `railway2`.`route` (`route_id`, `departure_station_id`, `arrival_station_id`, `distance`) VALUES ('8', '3', '4', '132');
INSERT INTO `railway2`.`route` (`route_id`, `departure_station_id`, `arrival_station_id`, `distance`) VALUES ('9', '3', '5', '420');
INSERT INTO `railway2`.`route` (`route_id`, `departure_station_id`, `arrival_station_id`, `distance`) VALUES ('10', '3', '6', '338');
INSERT INTO `railway2`.`route` (`route_id`, `departure_station_id`, `arrival_station_id`, `distance`) VALUES ('11', '3', '8', '438');
INSERT INTO `railway2`.`route` (`route_id`, `departure_station_id`, `arrival_station_id`, `distance`) VALUES ('12', '3', '9', '378');
INSERT INTO `railway2`.`route` (`route_id`, `departure_station_id`, `arrival_station_id`, `distance`) VALUES ('13', '4', '3', '132');
INSERT INTO `railway2`.`route` (`route_id`, `departure_station_id`, `arrival_station_id`, `distance`) VALUES ('14', '4', '6', '439');
INSERT INTO `railway2`.`route` (`route_id`, `departure_station_id`, `arrival_station_id`, `distance`) VALUES ('15', '11', '2', '707');
INSERT INTO `railway2`.`route` (`route_id`, `departure_station_id`, `arrival_station_id`, `distance`) VALUES ('16', '2', '4', '1728');

# INSERTING VALUES INTO JOURNEY TABLE
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('1', '1', '1', '2021-12-26', '2021-12-26', '09:00', '14:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('2', '1', '1', '2021-12-29', '2021-12-29', '09:00', '14:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('3', '2', '1', '2021-12-29', '2021-12-29', '12:00', '16:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('4', '2', '1', '2021-12-29', '2021-12-30', '21:00', '01:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('5', '3', '1', '2022-01-01', '2022-01-01', '08:00', '12:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('6', '1', '2', '2021-12-30', '2021-12-31', '06:00', '06:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('7', '2', '2', '2022-01-01', '2022-01-02', '08:00', '08:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('8', '5', '2', '2022-01-01', '2022-01-02', '08:00', '08:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('9', '6', '3', '2022-01-04', '2022-01-04', '12:00', '16:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('10', '5', '3', '2022-01-03', '2022-01-03', '11:00', '15:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('11', '4', '3', '2022-01-07', '2022-01-07', '11:00', '15:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('12', '5', '4', '2022-01-07', '2022-01-07', '11:00', '15:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('13', '5', '4', '2022-01-03', '2022-01-03', '19:00', '23:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('14', '6', '4', '2022-01-03', '2022-01-03', '14:00', '19:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('15', '3', '5', '2021-12-30', '2021-12-31', '20:00', '04:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('16', '2', '5', '2021-12-31', '2021-12-31', '08:00', '16:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('17', '3', '7', '2022-01-02', '2022-01-02', '08:00', '12:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('18', '4', '7', '2022-01-01', '2022-01-01', '12:00', '16:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('19', '1', '8', '2022-01-08', '2022-01-09', '22:00', '01:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('20', '2', '10', '2022-01-02', '2022-01-02', '08:00', '14:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('21', '3', '12', '2021-12-31', '2021-12-31', '08:00', '14:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('22', '2', '13', '2022-01-08', '2022-01-08', '14:00', '16:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('23', '4', '13', '2022-01-02', '2022-01-02', '18:00', '20:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('24', '6', '13', '2022-01-01', '2022-01-01', '14:00', '16:00');
INSERT INTO `railway2`.`journey` (`journey_id`, `train_id`, `route_id`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`) VALUES ('25', '3', '16', '2022-01-10', '2022-01-11', '08:00', '00:00');

# INSERTING VALUES INTO PAYMENT METHOD TABLE
INSERT INTO `railway2`.`payment_method` (`method_id`, `name`) VALUES ('1', 'visa card');
INSERT INTO `railway2`.`payment_method` (`method_id`, `name`) VALUES ('2', 'master card');
INSERT INTO `railway2`.`payment_method` (`method_id`, `name`) VALUES ('3', 'easy paisa');

# INSERTING VALUES INTO RATES TABLE
insert into rates values(1, "Fuel", 140, default);

# INSERTING VALUES INTO THE GENERAL SEATING TABLE
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('1', 'B', 'A', '1');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('2', 'B', 'A', '2');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('3', 'B', 'A', '3');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('4', 'B', 'A', '4');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('5', 'B', 'A', '5');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('6', 'B', 'A', '6');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('7', 'B', 'A', '7');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('8', 'B', 'A', '8');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('9', 'B', 'A', '9');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('10', 'B', 'A', '10');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('11', 'B', 'A', '11');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('12', 'B', 'A', '12');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('13', 'B', 'A', '13');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('14', 'B', 'A', '14');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('15', 'B', 'A', '15');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('16', 'B', 'A', '16');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('17', 'B', 'A', '17');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('18', 'B', 'A', '18');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('19', 'B', 'A', '19');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('20', 'B', 'A', '20');

INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('21', 'B', 'B', '1');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('22', 'B', 'B', '2');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('23', 'B', 'B', '3');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('24', 'B', 'B', '4');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('25', 'B', 'B', '5');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('26', 'B', 'B', '6');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('27', 'B', 'B', '7');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('28', 'B', 'B', '8');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('29', 'B', 'B', '9');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('30', 'B', 'B', '10');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('31', 'B', 'B', '11');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('32', 'B', 'B', '12');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('33', 'B', 'B', '13');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('34', 'B', 'B', '14');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('35', 'B', 'B', '15');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('36', 'B', 'B', '16');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('37', 'B', 'B', '17');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('38', 'B', 'B', '18');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('39', 'B', 'B', '19');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('40', 'B', 'B', '20');

INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('41', 'E', 'C', '1');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('42', 'E', 'C', '2');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('43', 'E', 'C', '3');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('44', 'E', 'C', '4');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('45', 'E', 'C', '5');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('46', 'E', 'C', '6');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('47', 'E', 'C', '7');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('48', 'E', 'C', '8');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('49', 'E', 'C', '9');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('50', 'E', 'C', '10');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('51', 'E', 'C', '11');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('52', 'E', 'C', '12');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('53', 'E', 'C', '13');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('54', 'E', 'C', '14');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('55', 'E', 'C', '15');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('56', 'E', 'C', '16');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('57', 'E', 'C', '17');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('58', 'E', 'C', '18');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('59', 'E', 'C', '19');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('60', 'E', 'C', '20');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('61', 'E', 'C', '21');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('62', 'E', 'C', '22');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('63', 'E', 'C', '23');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('64', 'E', 'C', '24');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('65', 'E', 'C', '25');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('66', 'E', 'C', '26');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('67', 'E', 'C', '27');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('68', 'E', 'C', '28');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('69', 'E', 'C', '29');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('70', 'E', 'C', '30');

INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('71', 'E', 'D', '1');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('72', 'E', 'D', '2');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('73', 'E', 'D', '3');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('74', 'E', 'D', '4');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('75', 'E', 'D', '5');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('76', 'E', 'D', '6');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('77', 'E', 'D', '7');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('78', 'E', 'D', '8');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('79', 'E', 'D', '9');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('80', 'E', 'D', '10');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('81', 'E', 'D', '11');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('82', 'E', 'D', '12');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('83', 'E', 'D', '13');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('84', 'E', 'D', '14');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('85', 'E', 'D', '15');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('86', 'E', 'D', '16');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('87', 'E', 'D', '17');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('88', 'E', 'D', '18');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('89', 'E', 'D', '19');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('90', 'E', 'D', '20');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('91', 'E', 'D', '21');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('92', 'E', 'D', '22');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('93', 'E', 'D', '23');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('94', 'E', 'D', '24');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('95', 'E', 'D', '25');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('96', 'E', 'D', '26');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('97', 'E', 'D', '27');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('98', 'E', 'D', '28');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('99', 'E', 'D', '29');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('100', 'E', 'D', '30');

INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('101', 'E', 'E', '1');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('102', 'E', 'E', '2');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('103', 'E', 'E', '3');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('104', 'E', 'E', '4');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('105', 'E', 'E', '5');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('106', 'E', 'E', '6');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('107', 'E', 'E', '7');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('108', 'E', 'E', '8');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('109', 'E', 'E', '9');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('110', 'E', 'E', '10');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('111', 'E', 'E', '11');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('112', 'E', 'E', '12');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('113', 'E', 'E', '13');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('114', 'E', 'E', '14');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('115', 'E', 'E', '15');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('116', 'E', 'E', '16');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('117', 'E', 'E', '17');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('118', 'E', 'E', '18');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('119', 'E', 'E', '19');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('120', 'E', 'E', '20');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('121', 'E', 'E', '21');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('122', 'E', 'E', '22');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('123', 'E', 'E', '23');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('124', 'E', 'E', '24');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('125', 'E', 'E', '25');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('126', 'E', 'E', '26');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('127', 'E', 'E', '27');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('128', 'E', 'E', '28');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('129', 'E', 'E', '29');
INSERT INTO `railway2`.`general_seating` (`id`, `class`, `cargo`, `seat`) VALUES ('130', 'E', 'E', '30');